package ex01;

public class ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		for (i = 1; i <= 10; i++) {
			System.out.printf("%4d", i);
		}
	}

}
