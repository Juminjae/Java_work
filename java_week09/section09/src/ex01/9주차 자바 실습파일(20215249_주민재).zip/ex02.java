package ex01;

public class ex02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		while (i <= 10) {
			System.out.printf("%4d", i);
			i++;
		}
	}

}
