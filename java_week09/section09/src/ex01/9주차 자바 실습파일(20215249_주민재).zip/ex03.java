package ex01;

public class ex03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		for (i = 1; i <= 10; i += 2) {
			System.out.printf("%4d", i);
		}
	}

}
