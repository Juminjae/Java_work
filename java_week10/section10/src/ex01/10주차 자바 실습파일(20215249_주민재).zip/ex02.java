package ex01;

import java.util.Scanner;

public class ex02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int in, i = 1; 
		int sum = 0; 
		double average = 0;
		Scanner input = new Scanner(System.in);
		
		do 
		{
			System.out.print("�����Է� : ");
			in = input.nextInt();
			if(in==0) break;
			sum += in;
			average = (double)sum/ i;
			System.out.printf("�� : %d", "��� : %.1f\n", sum, average);
			i++;
		} while(true);
		
		System.out.print("����");
	}

}
